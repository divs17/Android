package com.example.diceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ImageView DiceImage1 = findViewById(R.id.imgDice1);
        final ImageView DiceImage2 = findViewById(R.id.imgdice2);
        final MediaPlayer mp = MediaPlayer.create(this,R.raw.dice_sound);
        //Create an array of all the dice images
        final int [] DiceArray = {R.drawable.dice1, R.drawable.dice2, R.drawable.dice3, R.drawable.dice4, R.drawable.dice5, R.drawable.dice6};

        Button btnRoll = findViewById(R.id.btnRollTheDice);

        btnRoll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Random rndObject = new Random(); //to get random numbers we need to create a random object

                int myRandomNumber = rndObject.nextInt(6); // 0 ..... 5 //Assign the random number to the variable

                int myRandomNumber2 = rndObject.nextInt(6); //0.....5 //Same as above

                Log.i("MyApp", "The generated random number is " + myRandomNumber); //To see what happens in the LogCat wen we press the button

                DiceImage1.setImageResource(DiceArray[myRandomNumber]); //Gives us the random dice numbers from diceImage1 through 6
                DiceImage2.setImageResource(DiceArray[myRandomNumber2]); // this is for the second dice image

                //Animation effect we used by importing external animation library from Github
                YoYo.with(Techniques.Shake)
                        .duration(400) //millisecconds
                        .repeat(0)
                        .playOn(DiceImage1);

                YoYo.with(Techniques.Shake)
                        .duration(400) //milliseconds
                        .repeat(0)
                        .playOn(DiceImage2);


                mp.start(); //This plays the sound of the dice rolling
            }
        });


    }
}